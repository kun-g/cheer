#!/bin/bash
export PATH=$PATH:/usr/lib/fluent/ruby/bin/
echo "install dep software"
sudo apt-get -y update && sudo apt-get -y install python-software-properties

sudo apt-get -y install build-essential
sudo add-apt-repository 'deb http://ppa.launchpad.net/ondrej/mysql-5.6/ubuntu precise main'
sudo add-apt-repository ppa:ubuntu-toolchain-r/test
sudo apt-get -y update; sudo apt-get -y install gcc-4.8 g++-4.8
sudo update-alternatives --remove-all gcc 
sudo update-alternatives --remove-all g++
sudo update-alternatives --install /usr/bin/gcc gcc /usr/bin/gcc-4.8 20
sudo update-alternatives --install /usr/bin/g++ g++ /usr/bin/g++-4.8 20
sudo update-alternatives --config gcc
sudo update-alternatives --config g++

sudo apt-get -y install make
sudo apt-get -y install curl
sudo apt-get -y install libcurl3 libcurl3-gnutls libcurl4-openssl-dev

echo "install node"
wget http://nodejs.org/dist/v0.10.32/node-v0.10.32.tar.gz
tar -xzf node-v0.10.32.tar.gz
cd node-v0.10.32
./configure
sudo make 
sudo make install

cd ..

echo "install redis"

wget http://download.redis.io/redis-stable.tar.gz
tar xvzf redis-stable.tar.gz
cd redis-stable
make
sudo cp src/redis-server /usr/local/bin
sudo cp src/redis-cli /usr/local/bin

cd ..

echo "install git"

sudo apt-get -y install git-core
git config --global user.name "faruba"
git config --global user.email farubafaruba@126.com

echo "install pm2"
sudo npm install -g pm2  --unsafe-perm

echo "install td-agent"
curl -L http://toolbelt.treasuredata.com/sh/install-ubuntu-precise.sh | sh
sudo cp -f td-agent.conf /etc/td-agent/
gem install fluent-plugin-elasticsearch
sudo /etc/init.d/td-agent restart

echo "install mysql"
sudo apt-get -y install mysql-server-5.6

echo "ubuntu	soft	nofile	2048"  >>/etc/security/limits.conf
echo "ubuntu	hard	nofile	2048"  >>/etc/security/limits.conf
sed -i 's/# session    required   pam_limits.so/session    required   pam_limits.so/g' /etc/pam.d/su

